Place the "ArmorEnhancer" directory in your "Gamedata" directory of your ksp game.

